# Export and Delivery

## Validate one file first

1. Read the final output frame names, dimensions, and export settings. Exclude the master, annotations, and containing canvas section from the deliverable set.
2. Export only the intended node's content. Preserve transparency that belongs to the approved artwork; do not capture the canvas or section background outside rounded artwork.
3. Download one representative output immediately. Check its signature, decoded dimensions, alpha when applicable, and visual appearance before exporting all remaining locales. A successful request or a `.png` filename does not prove that the file contains PNG bytes.

## Figma routes

Use a supported asset-export tool when its sample passes. If it includes surrounding canvas content, use the Plugin API with explicit node-only content, such as `node.exportAsync({format: 'PNG', constraint: {type: 'SCALE', value: 1}, contentsOnly: true})` for a native-size PNG. Honor the requested scale instead of always using 1.

In environments exposing `node.screenshot({scale: 1, contentsOnly: true})`, the returned PNG image content is an alternative. Save the returned binary/base64 data directly; do not take a desktop screenshot or resize a preview. Explicitly specify the required scale because preview defaults may reduce dimensions. Verify the saved file's dimensions and alpha before using this route in bulk.

Capture the node-to-filename mapping alongside each tool result. Use small batches within tool limits, check response image counts, and retain completed files when retrying an incomplete batch. Never claim delivery based only on URLs or inline previews.

## Download and package

- Temporary asset URLs can expire. Download promptly and keep the URLs out of user-facing reports.
- Check downloaded byte counts and decoding. Retry empty, truncated, or invalid responses through a supported route; never treat existing zero-byte files as completed downloads.
- Run `scripts/verify_png_exports.py` with the expected name list and applicable dimension, alpha, and size requirements. Visually inspect representative short, long, RTL, and complex-script PNGs.
- Stage and verify in the workspace before copying to the user's destination. Keep scripts, URL manifests, base64 intermediates, and QA scratch files outside the delivery folder.
- When a ZIP is requested, put the requested output folder inside it, check archive integrity, and compare its entries with the verified files. Do not assume ZIP is needed for every export request.
- Preserve existing destination files. If a prior delivery occupies the same path, use a clear new version or ask only when replacing it is necessary and authorization is unclear.
