---
name: extend-multilingual-designs
description: Adapt a Figma design into multiple locales from one or more localization files, then audit copy, locale mapping, frame naming, typography, layout, and exports. Use for multilingual banners, cards, popups, campaign graphics, UI panels, or other repeated Figma variants when inputs may be XLSX/CSV/TSV, table structures may vary, layouts may require iterative adjustment, and deliverables need locale-based filenames.
---

# Extend Multilingual Designs

Treat product localization files as the copy source of truth and the approved Figma template as the visual source of truth. Adapt to each project's inputs; never assume a fixed table count, text-line count, canvas size, corner radius, font, safe area, export format, or file-size limit.

Accept natural-language task constraints as per-run parameters: copy roles, minimum font size, whether a role may be omitted, alignment after omission, output region, and export requirements. Do not carry numerical thresholds or locale decisions from a previous project into a new one. The user need not repeat the standard preservation, naming, and audit rules below.

## Required companion skills

- Use the spreadsheet skill to read standalone XLSX/CSV/TSV inputs.
- Use `figma-use` before every programmatic Figma inspection or edit.
- Use the relevant document skill when localization arrives in another structured format.

Read [references/intake-and-qa.md](references/intake-and-qa.md) for the intake summary, mapping rules, and final checklist. Read [references/layout-and-typography.md](references/layout-and-typography.md) when creating or adjusting variants.

## Workflow

### 1. Inspect before editing

Collect and inspect:

- Figma file, target page, approved template node, and existing variants.
- Every localization file supplied for the task.
- Output requirements such as format, dimensions, transparency, naming, size limit, and destination.
- User annotations or manually adjusted variants that override earlier assumptions.

Infer the localization schema rather than expecting a particular layout. A workbook may contain one sheet or many; copy fields may be rows, columns, key/value records, or separate files. Identify locale identifiers, copy roles, and source keys from labels and content.

Use user-designated canvas labels such as “母版” and “多语言输出” to locate the template and destination when unambiguous. Filenames such as “第一行” and “第二行” are clues to copy roles, not a requirement for exactly two files or two text layers. Inspect their contents and the user's role mapping before assigning layers.

Never align copy by column position alone. Join by normalized locale identifier and preserve the original locale spelling chosen for output naming.

### 2. Produce an intake summary

Before bulk creation, report:

- Detected localization files, sheets, locale columns/rows, and copy roles.
- Locale set in each source and any missing, duplicate, blank, or ambiguous entries.
- Template size, text layers, safe area, background treatment, alignment, spacing, radius/transparency, and current fonts.
- Proposed locale-to-frame names and expected copy-layer count per locale.
- Assumptions requiring confirmation.

Ask only about ambiguities that materially change output. If the user has already decided which locales keep or remove copy layers, treat that decision as authoritative and do not re-evaluate it.

Do not begin bulk edits until the mapping and template interpretation are sufficiently clear, unless the user explicitly asks for immediate execution.

### 3. Build a representative sample

Create or update a small sample before full rollout when the visual rules are new or uncertain. Include:

- One short Latin locale.
- One long locale.
- One RTL or complex-script locale when present.

Use the template's editable layers and current structure. Do not redraw assets that can be reused. Keep the sample editable.

If the user changes the background, safe area, alignment, line count, spacing, or vertical position, update the template rule first and then propagate consistently. Screenshots with annotations are optional: use them only when the Figma structure does not communicate the constraint.

### 4. Extend all locales

For every locale:

1. Duplicate from the current approved template or designated master.
2. Name the output frame with the exact approved locale code.
3. Insert each copy role into its matching text layer; never shift subtitle copy into the title layer or vice versa.
4. Preserve exact product copy, including punctuation, capitalization, spaces, diacritics, and Unicode characters.
5. Respect the user-approved number of visible copy layers for that locale.
6. Fit copy inside the defined safe area without exceeding it. Adjust font size only when allowed; do not silently change wording or add lines.
7. Preserve template dimensions, radius, transparency, imagery, alignment, and spacing unless the current task explicitly changes them.

When the user specifies a minimum size and omission rule, measure the complete text with its final font in the available region. Text that fits at exactly the threshold stays visible; omit it only if it needs a smaller size, then apply the requested alignment to the remaining content. Without an omission rule, report the conflict instead of dropping copy. See the layout reference for annotation and actual glyph-bound checks.

### 5. Handle typography deliberately

Use project or brand fonts when the required glyphs are supported. Verify the exact family/style is available and loadable in Figma.

For unsupported scripts, use an explicit language-appropriate fallback rather than leaving an implicit system fallback. Preserve the intended weight hierarchy. Report every fallback family used and its locale coverage.

Do not make commercial-license claims without evidence or user-provided internal authorization. Open-font status and internal brand-font authorization are separate questions.

### 6. Run the final audit

Perform a fresh read-only extraction from the final Figma state. Do not rely on cached copy from an earlier iteration.

Check all of the following:

- Every expected locale has exactly one output frame unless otherwise specified.
- No unexpected locale frames, duplicate names, or malformed locale codes exist.
- Frame names match the approved output names exactly.
- Every visible copy layer matches the correct source role and locale character-for-character.
- Multi-layer variants pull every layer from the same locale.
- Visible copy-layer count matches the user's final decision.
- Fonts are explicit and loadable; no unintended fallback remains.
- Text stays within the safe area and respects alignment, spacing, and line-count rules.
- Canvas dimensions, background, radius, and transparency match the approved template.

Report exceptions only after checking all outputs. Never say “all correct” based only on a screenshot.

### 7. Export only when requested

Use the final audited frame names as filenames. Preserve exact case and separators: `<locale>.<ext>`.

Export at the template's native size unless another scale or dimension is specified. If transparency or rounded transparent corners are required, verify alpha after export.

Before bulk export, follow [references/export-and-delivery.md](references/export-and-delivery.md): verify one native-size file with node-only content and the intended transparency, then use that validated route for all locales.

If a file-size limit exists:

1. Try lossless optimization first.
2. Apply minimal controlled compression only when needed.
3. Re-check pixel dimensions, alpha, file size, and representative visual quality.

Run `scripts/verify_png_exports.py` for PNG deliverables. Copy the completed folder to the requested destination only after verification. Writing outside the workspace may require user approval.

## Completion report

State:

- Number of variants audited and exported.
- Naming convention and output location.
- Dimensions, format, transparency, and size-limit result when applicable.
- Any intentionally omitted locale or blank source entry.
- Any fallback fonts or unresolved exceptions.

Do not claim completion if required copy mapping, final Figma audit, or export verification remains incomplete.
