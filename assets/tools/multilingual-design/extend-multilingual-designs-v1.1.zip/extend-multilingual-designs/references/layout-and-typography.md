# Layout and Typography

## Establish the template rule

Read constraints from editable Figma nodes in this order:

1. Explicit text container or safe-area frame.
2. Auto-layout padding, alignment, and spacing.
3. Approved example variant.
4. User annotation or screenshot.
5. Ask the user if the rule remains ambiguous.

Do not infer fixed values from a previous project.

Treat a colored overlay as a safe-area annotation only when user designation, layer naming, or the surrounding design makes that purpose clear. Record its bounds and preserve the template's text inset; do not assume the whole overlay width is available from the text's left edge. Hide identified annotation layers in output copies and leave the original master intact. Color or low opacity alone is not enough to distinguish annotation from artwork; resolve material ambiguity before hiding it.

## Text fitting

- Preserve copy and approved visible layer count.
- Keep each semantic copy role in its designated layer.
- Respect the safe area's left, right, top, and bottom boundaries.
- Preserve the specified alignment, including intentional left alignment for RTL text when explicitly requested.
- Preserve inter-layer gap independently from line height.
- Scale typography consistently by role; avoid arbitrary per-locale visual weights.
- If copy cannot fit without violating minimum readability or line-count rules, flag it instead of forcing a broken result.

### Actual glyph bounds

Complex scripts and italics can extend beyond a text node's line box even when its width and height appear valid. After fitting, inspect actual rendered bounds (for example `absoluteRenderBounds` when available) and representative screenshots. Check both the safe area and the gap between visible glyphs, especially combining marks, ascenders, and descenders.

If glyphs overlap, adjust inter-layer spacing and recenter the text group within the permitted region while preserving the requested alignment and copy. Keep an explicitly fixed gap unless the user permits a change; if constraints conflict, report it. Recheck all affected locales after any adjustment. Do not hardcode a font list, numeric gap, or omission threshold from a rehearsal.

## Font selection

Use this priority:

1. Approved brand font with verified glyph support.
2. Approved project fallback for the script.
3. A clearly licensed, script-appropriate fallback.

Verify the actual Figma font family/style and loadability. A font name assigned to a layer does not prove that all glyphs are rendered from that font.

Keep a per-project record such as:

```text
Latin/Greek/Cyrillic → brand display + text families
Arabic/Urdu → approved Arabic family
Hebrew → approved Hebrew family
CJK → approved JP/KR/SC/TC families
Khmer/Thai/Burmese → approved script-specific families
```

This is an example structure, not a fixed font list.

## Iteration discipline

When a visual rule changes:

1. Identify the newest approved template or example.
2. Record the changed constraint explicitly.
3. Propagate only that rule across variants.
4. Re-run layout checks across short, long, RTL, and complex-script samples.
5. Re-run the complete content audit before export.

Do not rebuild already-approved details unnecessarily.
