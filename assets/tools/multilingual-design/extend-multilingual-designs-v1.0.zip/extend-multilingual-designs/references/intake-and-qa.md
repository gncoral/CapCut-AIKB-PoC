# Intake and QA

## Intake summary template

Use this structure before bulk execution:

```text
Inputs
- Figma: file / page / template node
- Localization sources: file → sheet → detected roles
- Output: destination, format, naming, size requirements

Detected mapping
- Locale count by source
- Copy roles: title / subtitle / CTA / ...
- Proposed frame names
- Copy-layer count by locale

Exceptions
- Missing or blank locale values
- Duplicate or conflicting locale values
- Unrecognized locale labels
- Template constraints not encoded in Figma

Assumptions requiring confirmation
- Only material ambiguities
```

## Locale mapping rules

1. Prefer explicit BCP-47-style locale codes such as `en`, `pt-BR`, or `zh-Hant-TW`.
2. Normalize only for matching: trim surrounding whitespace and compare case-insensitively where safe.
3. Preserve the approved original spelling for Figma frame names and exported filenames.
4. Treat aliases such as `fil`/`tl`, `he`/`iw`, or country names as ambiguous unless the project establishes a mapping.
5. Never match sources by column index when locale labels exist.
6. Keep blank values distinct from missing locale columns.
7. If the same locale appears twice with different copy, report the conflict instead of choosing one silently.

## Copy comparison rules

- Compare final Figma text with source cell strings exactly.
- Include punctuation, spaces, apostrophes, dashes, casing, diacritics, and script-specific marks.
- Do not auto-trim, normalize punctuation, translate, or rewrite during final comparison.
- Sort visible text layers by their semantic role when named; use visual order only when role names are unavailable.
- Verify that all copy layers in a frame map to the same locale.

## Final checklist

### Source integrity

- [ ] All supplied files and relevant sheets inspected.
- [ ] Locale sets compared across every copy source.
- [ ] Missing, blank, duplicate, and extra locales reported.
- [ ] Copy roles mapped explicitly.

### Figma integrity

- [ ] Expected frame count is correct.
- [ ] Frame names are unique and exact.
- [ ] Each copy layer matches its source role and locale exactly.
- [ ] User-approved copy-layer count is preserved.
- [ ] No text overflow or unintended clipping.
- [ ] Background, dimensions, radius, and alpha match the approved template.
- [ ] Fonts are explicit, available, and appropriate for each script.

### Export integrity

- [ ] Filenames equal approved frame names.
- [ ] Format and dimensions are correct.
- [ ] Transparency is retained when required.
- [ ] File-size limits are satisfied.
- [ ] Representative short, long, RTL, and complex-script outputs visually inspected.
- [ ] Output folder contains no missing, duplicate, or extra files.
