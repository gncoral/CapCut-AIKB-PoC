#!/usr/bin/env python3
"""Verify PNG count, names, dimensions, size limits, and transparent corners.

Uses only the Python standard library so the check works in a fresh Codex task.
The alpha check supports non-interlaced, 8-bit PNGs, which is the normal Figma
export format. Unsupported PNG encodings are reported instead of guessed.
"""

from __future__ import annotations

import argparse
import json
import struct
import zlib
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--names-file", type=Path, help="One expected filename or locale stem per line")
    parser.add_argument("--width", type=int)
    parser.add_argument("--height", type=int)
    parser.add_argument("--max-bytes", type=int)
    parser.add_argument("--transparent-corners", action="store_true")
    return parser.parse_args()


PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


def paeth(a: int, b: int, c: int) -> int:
    estimate = a + b - c
    distance_a = abs(estimate - a)
    distance_b = abs(estimate - b)
    distance_c = abs(estimate - c)
    if distance_a <= distance_b and distance_a <= distance_c:
        return a
    if distance_b <= distance_c:
        return b
    return c


def read_png(path: Path, need_alpha: bool) -> tuple[int, int, list[int] | None]:
    data = path.read_bytes()
    if not data.startswith(PNG_SIGNATURE):
        raise ValueError("invalid PNG signature")

    position = len(PNG_SIGNATURE)
    width = height = bit_depth = color_type = interlace = None
    compressed = bytearray()
    transparency: bytes | None = None

    while position + 12 <= len(data):
        length = struct.unpack(">I", data[position : position + 4])[0]
        kind = data[position + 4 : position + 8]
        payload_start = position + 8
        payload_end = payload_start + length
        if payload_end + 4 > len(data):
            raise ValueError("truncated PNG chunk")
        payload = data[payload_start:payload_end]
        position = payload_end + 4
        if kind == b"IHDR":
            width, height, bit_depth, color_type, _, _, interlace = struct.unpack(">IIBBBBB", payload)
        elif kind == b"IDAT":
            compressed.extend(payload)
        elif kind == b"tRNS":
            transparency = payload
        elif kind == b"IEND":
            break

    if None in (width, height, bit_depth, color_type, interlace):
        raise ValueError("missing IHDR")
    assert width is not None and height is not None
    assert bit_depth is not None and color_type is not None and interlace is not None
    if not need_alpha:
        return width, height, None
    if bit_depth != 8 or interlace != 0:
        raise ValueError(f"alpha check requires non-interlaced 8-bit PNG; got bitDepth={bit_depth}, interlace={interlace}")

    channels_by_type = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}
    if color_type not in channels_by_type:
        raise ValueError(f"unsupported PNG color type {color_type}")
    channels = channels_by_type[color_type]
    row_bytes = width * channels
    raw = zlib.decompress(bytes(compressed))
    expected = height * (row_bytes + 1)
    if len(raw) != expected:
        raise ValueError(f"unexpected decoded size {len(raw)}; expected {expected}")

    rows: list[bytearray] = []
    offset = 0
    previous = bytearray(row_bytes)
    for _ in range(height):
        filter_type = raw[offset]
        encoded = raw[offset + 1 : offset + 1 + row_bytes]
        offset += row_bytes + 1
        decoded = bytearray(row_bytes)
        for index, value in enumerate(encoded):
            left = decoded[index - channels] if index >= channels else 0
            above = previous[index]
            upper_left = previous[index - channels] if index >= channels else 0
            if filter_type == 0:
                predictor = 0
            elif filter_type == 1:
                predictor = left
            elif filter_type == 2:
                predictor = above
            elif filter_type == 3:
                predictor = (left + above) // 2
            elif filter_type == 4:
                predictor = paeth(left, above, upper_left)
            else:
                raise ValueError(f"unsupported PNG filter {filter_type}")
            decoded[index] = (value + predictor) & 0xFF
        rows.append(decoded)
        previous = decoded

    def alpha_at(x: int, y: int) -> int:
        pixel = rows[y][x * channels : (x + 1) * channels]
        if color_type == 6:
            return pixel[3]
        if color_type == 4:
            return pixel[1]
        if color_type == 3 and transparency is not None:
            palette_index = pixel[0]
            return transparency[palette_index] if palette_index < len(transparency) else 255
        if color_type == 0 and transparency is not None and len(transparency) >= 2:
            transparent_gray = struct.unpack(">H", transparency[:2])[0] & 0xFF
            return 0 if pixel[0] == transparent_gray else 255
        if color_type == 2 and transparency is not None and len(transparency) >= 6:
            transparent_rgb = tuple(value & 0xFF for value in struct.unpack(">HHH", transparency[:6]))
            return 0 if tuple(pixel[:3]) == transparent_rgb else 255
        return 255

    corners = [
        alpha_at(0, 0),
        alpha_at(width - 1, 0),
        alpha_at(0, height - 1),
        alpha_at(width - 1, height - 1),
    ]
    return width, height, corners


def main() -> int:
    args = parse_args()
    files = sorted(args.directory.glob("*.png"))
    issues: list[dict[str, object]] = []

    expected: set[str] | None = None
    if args.names_file:
        expected = set()
        for raw in args.names_file.read_text(encoding="utf-8").splitlines():
            name = raw.strip()
            if not name:
                continue
            expected.add(name if name.lower().endswith(".png") else f"{name}.png")
        actual = {file.name for file in files}
        for name in sorted(expected - actual):
            issues.append({"type": "missing_file", "name": name})
        for name in sorted(actual - expected):
            issues.append({"type": "extra_file", "name": name})

    rows = []
    for file in files:
        try:
            width, height, corners = read_png(file, args.transparent_corners)
            size = file.stat().st_size
            if args.width is not None and width != args.width:
                issues.append({"type": "width", "name": file.name, "expected": args.width, "actual": width})
            if args.height is not None and height != args.height:
                issues.append({"type": "height", "name": file.name, "expected": args.height, "actual": height})
            if args.max_bytes is not None and size >= args.max_bytes:
                issues.append({"type": "file_size", "name": file.name, "limit": args.max_bytes, "actual": size})
            if args.transparent_corners and corners is not None and any(alpha != 0 for alpha in corners):
                issues.append({"type": "corner_alpha", "name": file.name, "actual": corners})
            rows.append({"name": file.name, "width": width, "height": height, "bytes": size, "cornerAlpha": corners})
        except (OSError, ValueError, struct.error, zlib.error) as error:
            issues.append({"type": "invalid_png", "name": file.name, "detail": str(error)})

    result = {
        "ok": not issues,
        "count": len(files),
        "expectedCount": len(expected) if expected is not None else None,
        "issues": issues,
        "files": rows,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not issues else 1


if __name__ == "__main__":
    raise SystemExit(main())
